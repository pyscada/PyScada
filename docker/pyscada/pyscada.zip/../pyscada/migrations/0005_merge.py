# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('pyscada', '0003_auto_20151026_1826'),
        ('pyscada', '0004_unit_udunit'),
    ]

    operations = [
    ]
